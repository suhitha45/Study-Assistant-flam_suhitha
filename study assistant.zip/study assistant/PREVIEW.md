Previewing the Study Assistant

Run a local static server from the project folder and open the preview URL.

PowerShell / Windows (uses system Python):
```powershell
cd 'c:\Users\LAKSHMAN CHOWdary\study assistant'
py -m http.server 8000
```

macOS / Linux / WSL:
```bash
cd ~/path/to/study-assistant
python3 -m http.server 8000
```

Then open:

http://localhost:8000/
