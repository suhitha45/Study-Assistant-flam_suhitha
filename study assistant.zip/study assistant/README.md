# Study Assistant Frontend

A simple study assistant app built with plain HTML, CSS, and JavaScript.

## What it does
- Add study topics or subjects
- Save notes and due dates
- Mark items complete or delete them
- Store your list in browser localStorage

## Setup and run steps
1. Open the folder in VS Code:
   - `File` > `Open Folder...`
   - Select `c:\Users\LAKSHMAN CHOWDARY\study assistant`

2. Open `index.html` in your browser:
   - Right-click `index.html` and choose `Open with Live Server` if you have the Live Server extension.
   - Or open `index.html` directly in Chrome, Edge, or Firefox.

3. If you want a local server, run this command in PowerShell from the project folder:
   ```powershell
   cd 'c:\Users\LAKSHMAN CHOWDARY\study assistant'
   python -m http.server 5500