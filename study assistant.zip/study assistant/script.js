const topicInput = document.getElementById('topic');
const notesInput = document.getElementById('notes');
const priorityInput = document.getElementById('priority');
const dueInput = document.getElementById('due');
const addButton = document.getElementById('addButton');
const itemList = document.getElementById('itemList');
const emptyState = document.getElementById('emptyState');
const totalCount = document.getElementById('totalCount');
const doneCount = document.getElementById('doneCount');

let items = [];

// Timer state
let timerInterval = null;
let timerState = {
  running: false,
  endTime: null, // timestamp when timer ends
  remaining: 0, // ms when paused
};

const timerDisplay = document.getElementById('timerDisplay');
const timerMinutes = document.getElementById('timerMinutes');
const startPauseTimer = document.getElementById('startPauseTimer');
const resetTimer = document.getElementById('resetTimer');

function loadTimerState() {
  try {
    const raw = localStorage.getItem('studyAssistantTimer');
    if (!raw) return;
    const parsed = JSON.parse(raw);
    timerState = Object.assign(timerState, parsed);
  } catch (e) {
    console.warn('Failed to load timer state', e);
  }
}

function saveTimerState() {
  localStorage.setItem('studyAssistantTimer', JSON.stringify(timerState));
}

function formatMs(ms) {
  const total = Math.max(0, Math.floor(ms / 1000));
  const minutes = Math.floor(total / 60).toString().padStart(2, '0');
  const seconds = (total % 60).toString().padStart(2, '0');
  return `${minutes}:${seconds}`;
}

function updateTimerDisplay() {
  let ms = 0;
  if (timerState.running && timerState.endTime) {
    ms = timerState.endTime - Date.now();
    if (ms <= 0) {
      // finished
      clearInterval(timerInterval);
      timerInterval = null;
      timerState.running = false;
      timerState.remaining = 0;
      timerState.endTime = null;
      saveTimerState();
      timerDisplay.textContent = '00:00';
      startPauseTimer.textContent = 'Start';
      try { alert('Time is up!'); } catch (e) {}
      return;
    }
  } else {
    ms = timerState.remaining || 0;
  }
  timerDisplay.textContent = formatMs(ms);
}

function startTimerFromMinutes(mins) {
  const ms = mins * 60 * 1000;
  timerState.running = true;
  timerState.endTime = Date.now() + ms;
  timerState.remaining = ms;
  saveTimerState();
  if (timerInterval) clearInterval(timerInterval);
  timerInterval = setInterval(() => {
    // update remaining based on endTime
    const rem = Math.max(0, timerState.endTime - Date.now());
    timerState.remaining = rem;
    updateTimerDisplay();
  }, 250);
  updateTimerDisplay();
  startPauseTimer.textContent = 'Pause';
}

function pauseTimer() {
  if (!timerState.running) return;
  // compute remaining then stop
  const rem = Math.max(0, timerState.endTime - Date.now());
  timerState.running = false;
  timerState.remaining = rem;
  timerState.endTime = null;
  saveTimerState();
  if (timerInterval) clearInterval(timerInterval);
  timerInterval = null;
  updateTimerDisplay();
  startPauseTimer.textContent = 'Start';
}

function resetTimerState() {
  timerState.running = false;
  timerState.endTime = null;
  timerState.remaining = 0;
  saveTimerState();
  if (timerInterval) clearInterval(timerInterval);
  timerInterval = null;
  updateTimerDisplay();
  startPauseTimer.textContent = 'Start';
}

startPauseTimer && startPauseTimer.addEventListener('click', () => {
  if (!timerState.running) {
    // start or resume
    if (timerState.remaining && timerState.remaining > 0) {
      // resume
      timerState.running = true;
      timerState.endTime = Date.now() + timerState.remaining;
      saveTimerState();
      if (timerInterval) clearInterval(timerInterval);
      timerInterval = setInterval(() => {
        const rem = Math.max(0, timerState.endTime - Date.now());
        timerState.remaining = rem;
        updateTimerDisplay();
      }, 250);
      startPauseTimer.textContent = 'Pause';
    } else {
      const mins = parseInt(timerMinutes.value, 10) || 25;
      startTimerFromMinutes(mins);
    }
  } else {
    pauseTimer();
  }
});

resetTimer && resetTimer.addEventListener('click', () => {
  resetTimerState();
});


function loadItems() {
  const stored = localStorage.getItem('studyAssistantItems');
  if (!stored) {
    items = [];
    return;
  }

  try {
    items = JSON.parse(stored);
  } catch (error) {
    console.warn('Invalid studyAssistantItems storage, resetting local data.', error);
    items = [];
    saveItems();
  }
}

function saveItems() {
  localStorage.setItem('studyAssistantItems', JSON.stringify(items));
}

function updateSummary() {
  totalCount.textContent = items.length;
  doneCount.textContent = items.filter(item => item.done).length;
}

function renderList() {
  itemList.innerHTML = '';

  if (items.length === 0) {
    emptyState.style.display = 'block';
    return;
  }

  emptyState.style.display = 'none';

  items.forEach((item, index) => {
    const li = document.createElement('li');
    li.className = 'list-item' + (item.done ? ' completed' : '');

    const content = document.createElement('div');
    content.className = 'item-content';

    const header = document.createElement('div');
    header.className = 'item-header';

    const title = document.createElement('h3');
    title.textContent = item.topic;
    header.appendChild(title);

    const badge = document.createElement('span');
    badge.className = `badge ${item.priority}`;
    badge.textContent = item.priority;
    header.appendChild(badge);

    const note = document.createElement('p');
    note.className = 'item-text';
    note.textContent = item.notes || 'No notes provided.';

    const meta = document.createElement('div');
    meta.className = 'item-meta';

    const created = document.createElement('span');
    created.textContent = `Added: ${new Date(item.createdAt).toLocaleDateString()}`;
    meta.appendChild(created);

    if (item.dueDate) {
      const due = document.createElement('span');
      due.textContent = `Due: ${item.dueDate}`;
      meta.appendChild(due);
    }

    content.appendChild(header);
    content.appendChild(note);
    content.appendChild(meta);

    const actions = document.createElement('div');
    actions.className = 'item-actions';

    const completeButton = document.createElement('button');
    completeButton.className = 'complete';
    completeButton.textContent = item.done ? 'Mark incomplete' : 'Mark done';
    completeButton.addEventListener('click', () => {
      items[index].done = !items[index].done;
      saveItems();
      renderApp();
    });

    const deleteButton = document.createElement('button');
    deleteButton.className = 'delete';
    deleteButton.textContent = 'Delete';
    deleteButton.addEventListener('click', () => {
      items.splice(index, 1);
      saveItems();
      renderApp();
    });

    actions.appendChild(completeButton);
    actions.appendChild(deleteButton);

    li.appendChild(content);
    li.appendChild(actions);
    itemList.appendChild(li);
  });
}

function addItem() {
  const topic = topicInput.value.trim();
  const notes = notesInput.value.trim();
  const priority = priorityInput.value;
  const dueDate = dueInput.value;

  if (!topic) {
    alert('Please enter a topic or subject.');
    return;
  }

  items.unshift({
    topic,
    notes,
    priority,
    dueDate,
    done: false,
    createdAt: new Date().toISOString(),
  });

  saveItems();
  renderApp();
  topicInput.value = '';
  notesInput.value = '';
  dueInput.value = '';
  priorityInput.value = 'Medium';
}

function renderApp() {
  updateSummary();
  renderList();
}

addButton.addEventListener('click', addItem);

window.addEventListener('load', () => {
  loadItems();
  // load timer state and render app
  loadTimerState();
  // if timer was running, ensure interval resumes
  if (timerState.running && timerState.endTime) {
    if (timerInterval) clearInterval(timerInterval);
    timerInterval = setInterval(() => {
      const rem = Math.max(0, timerState.endTime - Date.now());
      timerState.remaining = rem;
      updateTimerDisplay();
    }, 250);
  }
  updateTimerDisplay();
  renderApp();
});
